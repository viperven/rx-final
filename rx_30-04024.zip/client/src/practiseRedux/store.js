import { configureStore } from "@reduxjs/toolkit";

const todoSlice = createSlice({
    name: "todo",
})
